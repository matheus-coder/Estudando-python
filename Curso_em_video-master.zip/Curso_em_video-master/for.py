for i in range (1,10,2):
    print(i)

conta de 1 em q começando de traz
for i in range (1, 10, -1):
    print(i)






