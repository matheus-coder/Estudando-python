'''PEGANDO TUDO/ se voce da um    importe doce      ele traz todos os doces
PEGANDO UM ITEM SEPARADO/ se voce  da um    from doce importe pudim     ele traz só o pudin
_____________
UTEIS:
--  --  --  --  --  --  --
ceil - arredonda para cima
floor - arredonda para baixo
trunc - ele elimina a virgula
pow - potencia
sqrt - rais quadrada
factorial - fatorial de um numero
--------------
Por exemplo:
'''

import math
num = int(input("digite um numero para saber a raiz²: "))
raiz = math.sqrt(num)
print("a Raiza²  de {} é igual a {}".format(num, math.floor(raiz)))

'''RESULTADO
digite um numero para saber a raiz²: 90
a Raiza²  de 90 é igual a 9
'''
PARAMOS
AQUI
NO MINUTO :17:57
https://www.youtube.com/watch?v=oOUyhGNib2Q&list=PLvE-ZAFRgX8hnECDn1v9HNTI71veL3oW0&index=24

