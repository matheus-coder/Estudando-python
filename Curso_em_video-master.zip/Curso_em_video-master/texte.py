x = 5;

if x > 0:
  print('x é um número positivo!', 200, 200);
