def taboada(num):
    a = 12
    for tab in range(numero,a):
        print(tab)

taboada(5)