k = int(input('primeiro numero: '))
u = int(input('primeiro segundo: '))
soma = k + u
#print(f'A soma dos numeros {k} + {u} é {soma}')
print('A soma é {}' .format20(soma))

