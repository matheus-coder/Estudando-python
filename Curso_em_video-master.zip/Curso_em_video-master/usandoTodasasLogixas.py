from ddef import taboada, bemvindo


taboada(4)
