def bemvindo():
    print(20* '=')
    print("Ola, seja bem vindo ")
    print(20 * '=')

# def taboada(num):


def contadonumeros():
    for n in range (0,15,2):

        print(n)


#conta de 1 em q começando de traz
def contandofinal():
    for l in range (10,0,-1):
        print(l)

def media()

bemvindo()
numero = int(input('digite um nuero para saber a taboada: '))


